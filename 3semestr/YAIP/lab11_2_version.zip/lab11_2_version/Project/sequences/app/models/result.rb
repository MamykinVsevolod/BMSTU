class Result < ApplicationRecord
end
