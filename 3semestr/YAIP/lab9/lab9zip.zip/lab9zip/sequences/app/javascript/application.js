// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "jquery"
import "jquery_ujs"
import "popper"
import "bootstrap"

import "@hotwired/turbo-rails"
import "controllers"
import "src/calc"
