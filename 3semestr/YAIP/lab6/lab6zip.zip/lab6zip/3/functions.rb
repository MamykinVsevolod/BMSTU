# frozen_string_literal: true
def intprg(a, b)
    yield a, b
  end