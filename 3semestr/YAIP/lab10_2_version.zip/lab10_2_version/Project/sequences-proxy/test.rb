target = "<?xml version=\"1.0\"?>\n<?xml-stylesheet type=\"text/xsl\" href=\"C:/Users/neizvestnyj/Desktop/BMSTU/Semestr_3/IPL/LW/LW10/Project/Sequences-proxy/public/some_transformer.xslt\"?>\n<catalog>\n  <cd>\n    <id>3</id>\n    <item>5</item>\n  </cd>\n</catalog>\n"
target.gsub(/href=.*.xslt"/, '')

puts target.gsub(/href=.*.xslt"/, '')
