def my_function(x, y)
  1 + (y - x).abs + (y - x)**2 / 2 + (y - x).abs**3 / 3
end
