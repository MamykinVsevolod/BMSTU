Rails.application.routes.draw do
  get 'sequences_api/view'

  # root 'sequences_api#view'
end
