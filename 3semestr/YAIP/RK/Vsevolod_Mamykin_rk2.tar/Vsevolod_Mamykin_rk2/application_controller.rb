# frozen_string_literal: true

# my class
class ApplicationController < ActionController::Base
end
