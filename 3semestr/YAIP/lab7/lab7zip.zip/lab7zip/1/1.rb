# frozen_string_literal: true



require_relative 'functions'

fill_the_files

